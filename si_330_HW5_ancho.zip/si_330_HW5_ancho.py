# coding=utf-8
import time
import tweepy
import json
import re
import nltk
from nltk import PorterStemmer
from nltk.classify import NaiveBayesClassifier
from nltk.corpus import movie_reviews
import csv
import pandas
import vincent

consumer_key = "EsRjuy0s567VdaZjq4t07ehez"
consumer_secret = "ENYzgF1YumpwWAxJnhvMb489xsqXMtsA89Y3B2MHnqNmDBBYk2"
access_token = "293653648-HGkrLLUwbPzhQbk1E9qtTrsyN6mLb5wK1RS9iA7C"
access_token_secret = "fgVqzSQKbRvQLQxC3AaTGb9XgAOloirFGxmJ69mKgcWfw"

keyword_list = ['winter'] #hashtag list

start_time = time.time() #grabs the system time

#Step 1: Download Streaming Tweets
#This is the listener, responsible for receiving data
class listener(tweepy.StreamListener):
    def __init__(self, start_time, time_limit):
        self.time = start_time
        self.limit = time_limit
        self.tweet_data = []

    def on_data(self, data):
        saveFile = open(r'si_330_ancho_rawtweets.json', 'w+')
        while (time.time() - self.time) < self.limit:
            print("time=", time.time() - self.time)
            try:
                #Twitter returns tweets in JSON format - we need to decode it first
                decoded = json.loads(data)
                data_write = json.dumps({'time': decoded['created_at'], 'tweet': decoded['text'].encode('utf-8')})
                self.tweet_data.append(data_write)
                return True
            except BaseException, e:
                print('failed on_data,' , str(e))
                print(data)
                pass
        for item in self.tweet_data:
            saveFile.write(str(item))
            saveFile.write('\n')
        saveFile.close()
        return True
                #*insert code here*
                # If rate limit notice, then make sure you filter it out
                # from your final outputs
	return False

def on_error(self, status):
    print status

def openJSON(file):
    data = []
    with open(file) as data_file:
        for line in data_file:
            data.append(json.loads(line))
    return data

def preProcessing(object):
    lowercaseTweet = object['tweet'].encode('utf-8').lower() #Convert the tweets to lower case.
    urlRemovedTweet = re.sub(r'http://[^\s]+|https://[^\s]+', 'URL', lowercaseTweet) #Replace URLs with the word ‘URL’
    usernameRemovedTweet = re.sub(r'@[^\s]+', 'AT_USER', urlRemovedTweet) #Replace @username with the word ‘AT_USER’.
    winterModifiedTweet = re.sub(r'#winter', 'winter', usernameRemovedTweet)#Replace #hashtag with the exact same word without the hash. E.g. #winter replaced with 'winter'.
    extraWhitespaceRemovedTweet = re.sub(r'(?<=\s)\s+', '', winterModifiedTweet)
    extraPunctuationRemovedTweet = re.sub(r'(?<=\?)\?+|(?<=!)!+', '', extraWhitespaceRemovedTweet) #Remove any excessive punctuations such as multiple white spaces or punctuations at the end of the tweet such ‘!!!!!?’
    object['tweet'] = extraWhitespaceRemovedTweet.decode('utf-8')
    return object

def extract_features(list, n):
    return zip(*[list[i:] for i in range(n)])

def load_training_data(filename):
    # Load csv file

    rows = []

    file = open(filename, 'rb')
    reader = list(csv.reader(file, skipinitialspace = True))
    is_firstline = True

    for row in reader:
        if is_firstline:
            is_firstline = False
            continue
        record = dict()
        record['tweet'] = row[0]
        record['user'] = row[1]
        record['sentiment'] = row[2]

        rows.append(record)
    file.close()

    #print(rows) #how to handle commas in strings in a csv

# For each tweet in training data:
# i) Preprocessing, get rid of irrelevant characters and
# take care of stemming.
# ii) Extract features from each tweet – Call extract_features
# function

    stemmer = PorterStemmer()

    newRows = []
    unigramList = []
    bigramList = []

    for object in rows: #get rid of "
            newObject = preProcessing(object)
            newObject['tweet'] = newObject['tweet'].replace('"', '')
            newRows.append(newObject)

    for object in newRows:
        originals = object['tweet'].split(' ')
        singles = [stemmer.stem(original) for original in originals]
        singlesList = []
        for item in singles:
            singlesList.append(item)
        #singlesString = ' '.join(singles)
        unigramList.append(extract_features(singlesList,1)) #unigram
        bigramList.append(extract_features(singlesList,2)) #bigram

    negids = movie_reviews.fileids('neg')
    posids = movie_reviews.fileids('pos')

    def word_feats(words):
        return dict([(stemmer.stem(word), True) for word in words])

    negfeats = [(word_feats(movie_reviews.words(fileids=[f])), 'neg') for f in negids]
    posfeats = [(word_feats(movie_reviews.words(fileids=[f])), 'pos') for f in posids]

# Train and evaluate classifier - NaiveBayes classifier
#(use first 800 as training, rest as test to evaluate)

    trainfeats = negfeats[:800] + posfeats[:800]
    testfeats = negfeats[800:] + posfeats[800:]
    labeled_set = negfeats[:] + posfeats[:]

    print 'train on %d instances, test on %d instances' % (len(trainfeats), len(testfeats))

    classifier = NaiveBayesClassifier.train(trainfeats)
    print 'accuracy:', nltk.classify.util.accuracy(classifier, testfeats)
    classifier.show_most_informative_features()

# Train final classifier using all labelled dataset.
    classifier = nltk.NaiveBayesClassifier.train(labeled_set)
    return classifier

def sentiment_analysis(classifier):
    data = openJSON('si_330_ancho_cleanedtweets.json')
    saveFile = open(r'si_330_ancho_labelledtweets.json', 'w+')
    with open('si_330_ancho_labelledtweets.json', 'w+') as fp: #use preProcessing and write out to new file
        for object in data:
            splitWords = object['tweet'].split(' ')
            feats = dict([(word, True) for word in splitWords])
            object['label'] = classifier.classify(feats)
            json.dump(object, fp)
            fp.write('\n')

def time_series_tweets():
	#open datafile with tweets and sentiments
	#Append data

    with open('si_330_ancho_labelledtweets.json') as graph_file:
        d = dict()
        time_array = []
      	for line in graph_file:
            #if(re.search('"pos"', line) is not None):
            data = json.loads(line)
            time_array.append(data['time'])

        # a list of "1" to count the dates
        ones = [1]*len(time_array)

        # the index of the series
        idx = pandas.DatetimeIndex(time_array)
        #print idx
        # the actual series (at series of 1s for the moment)
        t_array = pandas.Series(ones, index=idx)
        #print t_array

        # Resampling / bucketing
        t_array = t_array.resample('5s', how='sum').fillna(0)
        time_chart = vincent.Line(t_array)
        time_chart.axis_titles(x='Time', y='Freq')
        time_chart.to_json('term_freq.json')


if __name__ == '__main__':
    #Will listen Twitter stream for 1200 seconds
    l = listener(start_time, time_limit=1200)
    auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
    auth.set_access_token(access_token, access_token_secret)

    # In this example follow #sunday tag
    # Listen to Twitter streaming data for the given keyword. Narrow it down to English.

    #stream = tweepy.Stream(auth, l)
    #stream.filter(track=keyword_list, languages=['en'])
    data = openJSON('si_330_ancho_rawtweets.json')
    with open('si_330_ancho_cleanedtweets.json', 'w+') as fp: #use preProcessing and write out to new file
        for object in data:
            newObject = preProcessing(object)
            json.dump(newObject, fp)
            fp.write('\n')
    classifier = load_training_data('Hashtagwinter_trainingset - Hashtagwinter_trainingset.csv')
    sentiment_analysis(classifier)
    time_series_tweets()